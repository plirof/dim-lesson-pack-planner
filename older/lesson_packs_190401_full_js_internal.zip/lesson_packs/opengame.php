<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="el-gr" lang="el-gr" >
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Spec12.com - Games </title>
 </head>
 <body bgcolor="#000000" >
<!-- bgcolor="#808080"  = grey -->
 <center>

<?php


$name=$_POST["name"];
//$file=$_POST["file"];
$file=$_REQUEST["file"];

//echo "<h2><font color=red >  Spec12.com - Games - Play : $name </font></h2>";
//echo "<h1>AAAAAAAAAAAAAAA<font color=white> ".$file." </font></h1>";
?>


<embed src="<?php echo "$file"; ?>" width="90%" height="90%" bgcolor="#000000" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash"></embed>



</center> <br>
<!--<font color=lightgrey ><i>If you want to report this item, please contact the site admin. Thanks & enjoy </i></font>-->

</body>
</html>